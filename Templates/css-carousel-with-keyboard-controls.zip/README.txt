A Pen created at CodePen.io. You can find this one at http://codepen.io/dp_lewis/pen/hqylE.

 Not recommended for production use. But it seemed like a fun idea to see how far I could take a form with radio inputs.